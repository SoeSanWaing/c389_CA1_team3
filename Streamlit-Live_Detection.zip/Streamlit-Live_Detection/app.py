"""People Counting Assistant (Distracted Pedestrian Detection) — entry point.

This is a Streamlit multipage app. Run it with:

    streamlit run app.py

Pages (shown in the left sidebar):
    * Image Upload  — analyse a single walkway photo.
    * Live Webcam   — real-time detection via streamlit-webrtc.

The fine-tuned YOLO26n model lives at ``models/best.pt`` and detects four
classes: person_left, person_right, phone_using_left, phone_using_right.

Shared detection logic lives in ``pca_core`` (Streamlit-free, so it is safe to
import from the webcam background thread) and ``pca_ui`` (Streamlit widgets).
"""

from __future__ import annotations

import streamlit as st

import pca_core as core
import pca_ui as ui

st.set_page_config(
    page_title=f"{core.APP_TITLE} | Distracted Pedestrian Detection",
    page_icon="🚶",
    layout="wide",
)

ui.inject_css()
ui.render_header()

st.markdown(
    """
Welcome to the **People Counting Assistant**. Pick a mode from the sidebar:

- **🖼️ Image Upload** — upload a JPG/PNG walkway photo for a full analysis with
  KPI cards, a per-class breakdown and a downloadable JSON report.
- **📹 Live Webcam** — stream your camera and watch bounding boxes, live KPI
  cards and a one-click JSON snapshot update in real time.
"""
)

# Quick sanity check so model problems surface on the landing page too.
ui.load_model_or_stop()
st.success("Model loaded. Choose **Image Upload** or **Live Webcam** in the sidebar to begin.")

with st.sidebar:
    ui.render_model_card()
    st.caption("Select a page above to start.")
